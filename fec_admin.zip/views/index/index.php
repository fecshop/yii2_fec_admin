<style>
.indexmain ul li{
	font-size:17px;
	line-height:35px;color:#666;
	
	width:400px;
	margin:auto;
}
.indexmain h1{
	display: block;
    font-size: 32px;
    margin: auto;
    width: 200px;
	margin:10px auto 60px ;
}
.unitBox .pageFormContent{padding:0px;}
</style>


	<div class="page unitBox" style="display: block;">
		<div class="accountInfo">
			
			
			<p><span>您好：zqy(赵启勇)</span></p>
			<!--<p>Follow:<a href="http://weibo.com/dwzui" target="_blank">http://weibo.com/dwzui</a></p> -->
		</div>
		<div layouth="80" class="">
				
				<ul style="line-height:30px;text-align:center;margin-top:30px;">
					<li>
						<h1 style="font-size:36px;">FEC Admin</h1>
						
					</li>
					<li>1.网址：<a target="_blank" href="http://www.fancyecommerce.com">Fancy ECommerce</a></li>
					<li>2.github地址：<a  target="_blank"  href="https://github.com/fancyecommerce/yii2_fec_admin">https://github.com/fancyecommerce/yii2_fec_admin</a></li>
					<li>3.说明：本框架是由 yii2 + DWZ UI 整合而成</li>
					<li>4.框架简介参看：</li>
					<li>5.框架的详细说明参看</li>
					<li>6.框架的使用手册</li>
					<li>7.开发环境：本框架是在linux环境下开发</li>
					<li>8.意见反馈：联系邮箱 2358269014@qq.com</li>
				</ul>

		</div>
		
	
	</div>
					
		
				
				