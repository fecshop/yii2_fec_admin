<?php
namespace fecadmin\views\layouts;
use Yii;
use fec\helpers\CUrl;
class Footer{
	public static function getContent(){
		return '<div id="footer">Copyright &copy; 2010 <a href="" target="_blank">Tomtop团队 - www.tomtop.com</a></div>';
		
	}
	
	
}












?>