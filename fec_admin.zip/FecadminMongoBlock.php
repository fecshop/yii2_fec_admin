<?php
namespace fecadmin;
use fec\helpers\CRequest;
use fec\helpers\CUrl;
class  FecadminMongoBlock extends  FecadminbaseBlock{
	
	
	
	
	
}